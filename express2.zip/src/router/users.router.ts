import type { Router } from "express";

import { deleteUser, getAllUsers } from "../controllers/users.controller.js";
import { isAuthenticated, isOwner } from "../middlewares/middleware.js";

export default (router: Router) => {
  router.get("/users", isAuthenticated, getAllUsers);
  router.delete("/users/:id", isOwner, deleteUser);
};
