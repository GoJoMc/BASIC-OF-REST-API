import type { Request, Response } from "express";

import { deleteUserById, getUsers } from "../db/users.js";

export const getAllUsers = async (_: Request, res: Response) => {
  try {
    const users = await getUsers();
    return res.status(200).json(users);
  } catch (err) {
    console.log(err);
    return res.sendStatus(400);
  }
};

export const deleteUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id || typeof id !== "string") {
      return res.sendStatus(400);
    }

    const deletedUser = await deleteUserById(id);

    return res.json(deletedUser);
  } catch (err) {
    console.log(err);
    return res.sendStatus(400);
  }
};
